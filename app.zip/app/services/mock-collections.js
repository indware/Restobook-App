export let COLLECTIONS = [
  {
    id: 1,
    name: "Trending this Week",
    num_places: 30,
    num_bookmarks: 6268,
    background: "img/menu/r1.jpg",
    places: [1, 2, 3, 4]
  },
  {
    id: 2,
    name: "Ramen",
    num_places: 30,
    num_bookmarks: 6268,
    background: "img/menu/r2.jpg",
    places: [1, 2, 3, 4]
  },
  {
    id: 3,
    name: "Pizza",
    num_places: 30,
    num_bookmarks: 6268,
    background: "img/menu/r3.jpg",
    places: [1, 2, 3, 4]
  },
  {
    id: 4,
    name: "Steak",
    num_places: 30,
    num_bookmarks: 6268,
    background: "img/menu/r1.jpg",
    places: [1, 2, 3, 4]
  }
]