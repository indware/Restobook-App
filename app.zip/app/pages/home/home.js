
import { NavController, Loading } from 'ionic-angular';
import {Component} from '@angular/core';
import {PlaceService} from '../../services/place-service';
import {SelectLocationPage} from '../select-location/select-location';
import {PlacesPage} from '../places/places';
import {PlaceDetailPage} from '../place-detail/place-detail';
import {SearchPage} from '../search/search';
import {BookmarksPage} from '../bookmarks/bookmarks';
import {MapPage} from '../map/map';
import {NearbyPage} from '../nearby/nearby';

import {Geolocation} from 'ionic-native'

/*
 Generated class for the HomePage page.

 See http://ionicframework.com/docs/v2/components/#navigation for more info on
 Ionic pages and navigation.
 */
@Component({
  templateUrl: 'build/pages/home/home.html',
})

export class HomePage {
	
  static get parameters() {
  return [[NavController], [PlaceService]];
  
    map: any;
    google: any;
    markers = [];
    //loading: Loading = Loading.create();
	
  }
  
   
  
  constructor( nav, placeService) {
    this.nav = nav;
    // current location
    //this.currentLocation = 'New York, USA';

    // list slides for slider
    this.slides = [
      {
        src: 'img/bugger.jpg'
      },
      {
        src: 'img/drink.jpg'
      },
      {
        src: 'img/entree.jpg'
      }
    ];

    // list popular places
    this.popularPlaces = placeService.getAll();
	
	this.map = null;
    this.loadMap();
	
  }
  
  

  // go to select location page
  selectLocation() {
    this.nav.push(SelectLocationPage);
  }

  // go to places
  viewPlaces() {
    this.nav.rootNav.push(PlacesPage);
  }

  // view a place
  viewPlace(id) {
    this.nav.rootNav.push(PlaceDetailPage, {id: id});
  }

  // go to search page
  goToSearch() {
    this.nav.rootNav.push(SearchPage);
  }

  // go to bookmarks page
  goToBookmarks() {
    this.nav.rootNav.push(BookmarksPage);
  }

  // view map
  goToMap() {
    this.nav.rootNav.push(MapPage);
  }

  // view nearby page
  goToNearBy() {
    this.nav.rootNav.push(NearbyPage);
  }
  
  ///////////////////////map///////////////////////////////////////
  
  loadMap() {
    this.nav.present(this.loading);
    let options = {
      timeout: 10000,
      enableHighAccuracy: true
    };

    Geolocation.getCurrentPosition(options).then((position) => {
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

      let mapOptions = {
        center: latLng,
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      };

      this.map = new google.maps.Map(document.getElementById("map"), mapOptions);

      this.map.addListener('click', (event) => {
        this.addMarker(event.latLng);
      });

      this.loading.dismiss();

    });
  }

   /* addInfoWindow(marker, content: string) {
    let infoWindow = new google.maps.InfoWindow({
      content: content
    });
    google.maps.event.addListener(marker, 'click', function () {
      infoWindow.open(this.map, marker);
    })
  }  */

  addMarker(location) {
    if (!location) {
      location = this.map.getCenter();
    }
    let marker = new google.maps.Marker({
      map: this.map,
      animation: google.maps.Animation.DROP,
      position: location
    });

    this.markers.push(marker);

    //let content: string = 'remove';
    this.addInfoWindow(marker, content);
  }

  deleteAllMarkers() {
    this.clearMarkers();
    this.markers = [];
  }

  undoLastMarker() {
    let marker = this.markers.pop()
    if (marker) {
      marker.setMap(null);
    }
  }

  setMapOnAll(map) {
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(map);
    }
  }

  clearMarkers() {
    this.setMapOnAll(null);
  }
  
}