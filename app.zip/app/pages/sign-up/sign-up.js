import {NavController} from 'ionic-angular';
import {Component} from '@angular/core';
import {ForgotPasswordPage} from '../forgot-password/forgot-password';
import {HomePage} from '../home/home';
import {MainTabsPage} from '../main-tabs/main-tabs';

/*
 Generated class for the SignUpPage page.

 See http://ionicframework.com/docs/v2/components/#navigation for more info on
 Ionic pages and navigation.
 */
@Component({
  templateUrl: 'build/pages/sign-up/sign-up.html',
})
export class SignUpPage {
  static get parameters() {
    return [[NavController]];
  }

  constructor(nav) {
    this.nav = nav;
  }

  // go to forgot password page
  forgotPwd() {
    this.nav.push(ForgotPasswordPage);
  }

  // process sign up
  signUp() {
    // add our sign up code here
    this.nav.push(MainTabsPage);
  }
  
  
 
}
