import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {RestTabsPage} from '../rest-tabs/rest-tabs';

/*
  Generated class for the AdminloginPage page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  templateUrl: 'build/pages/adminlogin/adminlogin.html',
})
export class AdminloginPage {
  static get parameters() {
    return [[NavController]];
  }

  constructor(nav) {
    this.nav = nav;
  }
  
  adminreg() {
    // add your login code here
    this.nav.push(RestTabsPage);
  }
  
}
