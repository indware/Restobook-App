import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {HomeRestaurantPage} from '../home-restaurant/home-restaurant';
import {BranchesPage} from '../branches/branches';
import {ReservationPage} from '../reservation/reservation';
import {MenuEntryPage} from '../menu-entry/menu-entry';

/*
  Generated class for the RestTabsPage page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  templateUrl: 'build/pages/rest-tabs/rest-tabs.html',
})
export class RestTabsPage {
  static get parameters() {
    return [[NavController]];
  }

  constructor(nav) {
    this.nav = nav;
	this.tabHome = HomeRestaurantPage;
	this.tabBranches = BranchesPage;
	this.tabReservation = ReservationPage;
	this.tabMenu = MenuEntryPage;
  }
}
