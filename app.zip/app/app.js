import 'es6-shim';
import {ionicBootstrap, Platform} from 'ionic-angular';
import {Component} from '@angular/core';
import {StatusBar} from 'ionic-native';

// import services
import {PlaceService} from './services/place-service';
import {CollectionService} from './services/collection-service';
import {ReviewService} from './services/review-service';

// import pages
import {LoginPage} from './pages/login/login';
import {SignUpPage} from './pages/sign-up/sign-up';
import {ForgotPasswordPage} from './pages/forgot-password/forgot-password';
import {HomePage} from './pages/home/home';
import {MainTabsPage} from './pages/main-tabs/main-tabs';
import {PlacesPage} from './pages/places/places';
import {PlaceDetailPage} from './pages/place-detail/place-detail';
import {SelectLocationPage} from './pages/select-location/select-location';
import {SearchPage} from './pages/search/search';
import {AccountPage} from './pages/account/account';
import {CollectionsPage} from './pages/collections/collections';
import {FeedPage} from './pages/feed/feed';
import {MapPage} from './pages/map/map';
import {NearbyPage} from './pages/nearby/nearby';
import {BookmarksPage} from './pages/bookmarks/bookmarks';
import {MenuPage} from './pages/menu/menu';
import {ReviewsPage} from './pages/reviews/reviews';
import {PhotosPage} from './pages/photos/photos';
import {AdminloginPage} from './pages/adminlogin/adminlogin';
import {HomeRestaurantPage} from './pages/home-restaurant/home-restaurant';

@Component({
  template: '<ion-nav [root]="rootPage"></ion-nav>'
})
export class MyApp {
  static get parameters() {
    return [[Platform]];
  }

  constructor(platform) {
    this.rootPage = LoginPage;

    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
    });
  }
}

// Pass the main app component as the first argument
// Pass any providers for your app in the second argument
// Set any config for your app as the third argument:
// http://ionicframework.com/docs/v2/api/config/Config/

ionicBootstrap(MyApp, [PlaceService, CollectionService, ReviewService], {
  platforms: {
    android: {
      tabbarLayout: 'title-hide'
    },
    windows: {
      tabbarLayout: 'title-hide'
    }
  }
})
